require 'test_helper'

class ChampionshipTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
