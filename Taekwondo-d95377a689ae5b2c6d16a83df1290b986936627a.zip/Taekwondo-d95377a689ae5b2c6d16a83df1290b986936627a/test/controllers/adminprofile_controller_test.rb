require 'test_helper'

class AdminprofileControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
